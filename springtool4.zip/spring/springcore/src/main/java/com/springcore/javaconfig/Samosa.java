package com.springcore.javaconfig;

public class Samosa {
	public void display() {
		System.out.println("My price is little be high...");
	}
}
